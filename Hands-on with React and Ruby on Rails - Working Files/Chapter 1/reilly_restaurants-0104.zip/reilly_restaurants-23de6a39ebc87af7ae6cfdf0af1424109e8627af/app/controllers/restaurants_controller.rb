class RestaurantsController < ApplicationController

end
