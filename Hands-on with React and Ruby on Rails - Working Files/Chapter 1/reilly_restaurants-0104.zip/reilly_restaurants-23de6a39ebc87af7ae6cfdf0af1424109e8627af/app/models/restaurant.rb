class Restaurant < ActiveRecord::Base
  has_many :comments
end
