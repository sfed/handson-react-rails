require 'rails_helper'

describe :sanity do
  it 'works!' do
    expect(1).to eq 1
  end
end
