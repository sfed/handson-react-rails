import { Dispatcher } from 'flux';
let AppDispatcher = new Dispatcher();
export default AppDispatcher;
